package com.luv2code.junitdemo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class DemoUtilsTest {
	
	@Test
	void testEqualAndNotEqual() {
		
		DemoUtils demoUtils = new DemoUtils();
		
		int add = demoUtils.add(2, 3);
		
		Assertions.assertEquals(5, add, "2+3 gives 5");
		Assertions.assertNotEquals(6, add, "2+3 not gives 15");
	}
	
	
	@Test
	void testNullAndNotNull() {
		
		DemoUtils demoUtils = new DemoUtils();
		
		String s1 = null;
		String s2 = "NMM";

		Assertions.assertNull(demoUtils.checkNull(s1), "object should be null");
		Assertions.assertNotNull(demoUtils.checkNull(s2), "object should not be null");
		
	}

}
