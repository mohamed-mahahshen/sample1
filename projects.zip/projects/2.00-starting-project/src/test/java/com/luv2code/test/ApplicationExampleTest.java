package com.luv2code.test;

import com.luv2code.component.MvcTestingExampleApplication;
import com.luv2code.component.models.CollegeStudent;
import com.luv2code.component.models.StudentGrades;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = MvcTestingExampleApplication.class)
public class ApplicationExampleTest {

    private static int count;

    @Value("${info.school.name}")
    private String schoolName;

    @Value("${info.app.name}")
    private String appName;

    @Value("${info.app.description}")
    private String appInfo;

    @Value("${info.app.version}")
    private String appVersion;

    @Autowired
    CollegeStudent student;

    @Autowired
    StudentGrades studentGrades;

    @Autowired
    ApplicationContext context;



    @BeforeEach
    void beforeEach() {
        count++;
        System.out.println("Welcome to " + schoolName + "..! " + "\n"
                        + " " + appName + " uses " + appInfo + ", Which has a version of " + appVersion
                        + "\n" + " No. of times executed: " + count);
        student.setFirstname("Mohamed");
        student.setLastname("Mahashen");
        student.setEmailAddress("nmm@gmail.com");
        studentGrades.setMathGradeResults(new ArrayList<>(Arrays.asList(100.0, 85.0, 76.50, 91.75)));
        student.setStudentGrades(studentGrades);
    }


    @DisplayName("Add grade results for student grade")
    @Test
    public void addGradeResultForStudentGrades() {
        assertEquals(353.25,
                studentGrades.addGradeResultsForSingleClass(student.getStudentGrades().getMathGradeResults()));

    }

    @DisplayName("Add grade results for student grade not equals")
    @Test
    public void addGradeResultForStudentGradesAssertNotEquals() {
        assertNotEquals(0,
                studentGrades.addGradeResultsForSingleClass(student.getStudentGrades().getMathGradeResults()));

    }

    @DisplayName("Check the grades are greater : assertTrue")
    @Test
    public void isGradesAreGreaerAssertTrue() {
        assertTrue(studentGrades.isGradeGreater(98.5, 23), "Failure: It should be true");
    }

    @DisplayName("Check the grades are greater : assertFalse")
    @Test
    public void isGradesAreGreaerAssertFalse() {
        assertFalse(studentGrades.isGradeGreater(23, 98.5), "Failure: It should be false");
    }

    @DisplayName("Check the grades are null : assertNotNull")
    @Test
    public void isGradesAreNull() {
        assertNotNull(studentGrades.checkNull(student.getStudentGrades().getMathGradeResults()), "Object should not be null");
    }

    @DisplayName("Create Student without Grade init")
    @Test
    public void createStudentWithoutGradeInit() {
        CollegeStudent studentTwo = context.getBean("collegeStudent", CollegeStudent.class);
        studentTwo.setFirstname("Muhsin");
        studentTwo.setLastname("John Kumar");
        studentTwo.setEmailAddress("mohsin.john.kumar@yahoo.com");
        assertNotNull(studentTwo.getFirstname());
        assertNotNull(studentTwo.getLastname());
        assertNotNull(studentTwo.getEmailAddress());
        assertNull(studentGrades.checkNull(studentTwo.getStudentGrades()));
    }

    @DisplayName("Verify students are prototypes")
    @Test
    public void verifyStudentsArePrototypes() {
        CollegeStudent studentTwo = context.getBean("collegeStudent", CollegeStudent.class);
        assertNotSame(student, studentTwo);
    }

    @DisplayName("Find grade point average")
    @Test
    public void findGradePointAverage() {
        //assertEquals(, studentGrades.findGradePointAverage(student.getStudentGrades()));
        assertAll("Testing all asserts",
                () -> assertEquals(353.25, studentGrades.addGradeResultsForSingleClass(student.getStudentGrades().getMathGradeResults())),
                () -> assertEquals(88.31, studentGrades.findGradePointAverage(student.getStudentGrades().getMathGradeResults()))
        );
    }
}
