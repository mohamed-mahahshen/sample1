insert into student(id,name,branch) values(101,'Sam', 'Mech');
insert into student(id,name,branch) values(102,'Ajit', 'CSE');
insert into student(id,name,branch) values(103,'Boby','IT');
insert into student(id,name,branch) values(104,'Tony', 'EIE');
insert into student(id,name,branch) values(105,'Qalz', 'EEE');