package com.demo.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.springboot.dao.EmployeeRepository;
import com.demo.springboot.entity.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepo; 

	@Override
	//@Transactional // no need, as this 'll be managed by spring data JPA
	public List<Employee> findAll() {
		//return employeeRepo.findAll();
		return employeeRepo.findAllByOrderByFirstNameAsc();
	}

	@Override
	public Employee findById(int theId) {
		Optional<Employee> result = employeeRepo.findById(theId);
		Employee employee = null;
		if(result.isPresent()) {
			employee = result.get();
		}
		else {
			throw new RuntimeException("Did not find employee id - "+theId);
		}
		return employee;
	}

	@Override
	public void save(Employee theEmployee) {
		employeeRepo.save(theEmployee);
	}

	@Override
	public void deleteById(int theId) {
		employeeRepo.deleteById(theId);
	}

}
