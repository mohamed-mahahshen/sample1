package com.demo.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.springboot.entity.Employee;
import com.demo.springboot.service.EmployeeService;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	
	@GetMapping("/list")
	public String getEmployeesList(Model model) {
		
		// get employees from DB
		List<Employee> theEmployees = employeeService.findAll();
		
		model.addAttribute("employees", theEmployees);
		
		return "employees/employees-list";
	}
	
	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model model) {
		Employee theEmployee = new Employee();
		
		model.addAttribute("employee", theEmployee);
		
		return "employees/employee-form";
	}
	
	@PostMapping("/save")
	public String saveEmployee(@ModelAttribute("employee") Employee theEmployee) {
		employeeService.save(theEmployee);
		
		// use a redirect to prevent duplicate submission
		return "redirect:/employees/list"; // first method - getEmployeesList
	}
	
	@GetMapping("/showFormForUpdate")
	public String showFormforupdate(@RequestParam("employeeId") int empId,
										Model model) {
		Employee employeefromDB = employeeService.findById(empId);
		
		model.addAttribute("employee", employeefromDB);
		
		return "employees/employee-form";
	}
	
	@GetMapping("/delete")
	public String deleteEmployee(@RequestParam("employeeId") int empId) {
		
		Employee employeefromDB = employeeService.findById(empId);
		
		if(employeefromDB != null) {
			employeeService.deleteById(empId);
		}
		return "redirect:/employees/list";
	}
}
